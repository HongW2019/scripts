
# Replaced with the current commit when building the wheels.
__commit__ = "{{CLOUDTIK_COMMIT_SHA}}"
__version__ = "0.9.0"
